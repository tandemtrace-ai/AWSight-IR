import boto3
import json
import datetime
import os
from botocore.exceptions import ClientError

def collect_ec2_data():
    """Collect EC2 instance data including security groups and network interfaces"""
    ec2 = boto3.client('ec2')
    instances = []
    
    try:
        paginator = ec2.get_paginator('describe_instances')
        for page in paginator.paginate():
            for reservation in page['Reservations']:
                for instance in reservation['Instances']:
                    instance_data = {
                        'InstanceId': instance['InstanceId'],
                        'InstanceType': instance.get('InstanceType'),
                        'LaunchTime': instance.get('LaunchTime', '').isoformat() if 'LaunchTime' in instance else None,
                        'State': instance.get('State', {}).get('Name'),
                        'PrivateIpAddress': instance.get('PrivateIpAddress'),
                        'PublicIpAddress': instance.get('PublicIpAddress'),
                        'Platform': instance.get('Platform', 'linux'),
                        'VpcId': instance.get('VpcId'),
                        'SubnetId': instance.get('SubnetId'),
                        'SecurityGroups': instance.get('SecurityGroups', []),
                        'Tags': instance.get('Tags', []),
                        'NetworkInterfaces': []
                    }
                    
                    # Network interface details
                    for eni in instance.get('NetworkInterfaces', []):
                        interface_data = {
                            'NetworkInterfaceId': eni.get('NetworkInterfaceId'),
                            'PrivateIpAddresses': eni.get('PrivateIpAddresses', []),
                            'MacAddress': eni.get('MacAddress'),
                            'SecurityGroups': eni.get('Groups', [])
                        }
                        instance_data['NetworkInterfaces'].append(interface_data)
                    
                    instances.append(instance_data)
        return instances
    except Exception as e:
        print(f"Error collecting EC2 data: {str(e)}")
        return []

def collect_security_groups():
    """Collect security group configurations"""
    ec2 = boto3.client('ec2')
    try:
        security_groups = []
        paginator = ec2.get_paginator('describe_security_groups')
        for page in paginator.paginate():
            for sg in page['SecurityGroups']:
                security_groups.append({
                    'GroupId': sg['GroupId'],
                    'GroupName': sg['GroupName'],
                    'Description': sg['Description'],
                    'VpcId': sg.get('VpcId'),
                    'InboundRules': sg.get('IpPermissions', []),
                    'OutboundRules': sg.get('IpPermissionsEgress', [])
                })
        return security_groups
    except Exception as e:
        print(f"Error collecting security group data: {str(e)}")
        return []

def collect_iam_info():
    """Collect IAM users, roles, and policies"""
    iam = boto3.client('iam')
    try:
        data = {
            'Users': [],
            'Roles': [],
            'Policies': []
        }

        # Collect users
        paginator = iam.get_paginator('list_users')
        for page in paginator.paginate():
            for user in page['Users']:
                user_data = {
                    'UserName': user['UserName'],
                    'UserId': user['UserId'],
                    'Arn': user['Arn'],
                    'CreateDate': user['CreateDate'].isoformat(),
                    'AccessKeys': [],
                    'AttachedPolicies': []
                }
                
                try:
                    keys = iam.list_access_keys(UserName=user['UserName'])
                    user_data['AccessKeys'] = [{
                        'AccessKeyId': key['AccessKeyId'],
                        'Status': key['Status'],
                        'CreateDate': key['CreateDate'].isoformat()
                    } for key in keys['AccessKeyMetadata']]
                except Exception as e:
                    print(f"Error getting access keys for {user['UserName']}: {e}")

                try:
                    policies = iam.list_attached_user_policies(UserName=user['UserName'])
                    user_data['AttachedPolicies'] = policies['AttachedPolicies']
                except Exception as e:
                    print(f"Error getting policies for {user['UserName']}: {e}")

                data['Users'].append(user_data)

        # Collect roles
        paginator = iam.get_paginator('list_roles')
        for page in paginator.paginate():
            data['Roles'].extend(page['Roles'])

        return data
    except Exception as e:
        print(f"Error collecting IAM data: {str(e)}")
        return {}

def collect_vpc_info():
    """Collect VPC configurations"""
    ec2 = boto3.client('ec2')
    try:
        vpc_data = {
            'VPCs': [],
            'Subnets': [],
            'RoutesTables': [],
            'InternetGateways': [],
            'NATGateways': []
        }

        # Get VPCs
        vpcs = ec2.describe_vpcs()
        vpc_data['VPCs'] = vpcs['Vpcs']

        # Get Subnets
        subnets = ec2.describe_subnets()
        vpc_data['Subnets'] = subnets['Subnets']

        # Get Route Tables
        route_tables = ec2.describe_route_tables()
        vpc_data['RouteTables'] = route_tables['RouteTables']

        # Get Internet Gateways
        igws = ec2.describe_internet_gateways()
        vpc_data['InternetGateways'] = igws['InternetGateways']

        # Get NAT Gateways
        nat_gateways = ec2.describe_nat_gateways()
        vpc_data['NATGateways'] = nat_gateways['NatGateways']

        return vpc_data
    except Exception as e:
        print(f"Error collecting VPC data: {str(e)}")
        return {}

def store_data_in_s3(data, bucket_name, key_prefix):
    """Store collected data in S3"""
    s3 = boto3.client('s3')
    timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    
    try:
        s3.put_object(
            Bucket=bucket_name,
            Key=f"{key_prefix}/{timestamp}.json",
            Body=json.dumps(data, default=str, indent=2),
            ContentType='application/json'
        )
        return True
    except Exception as e:
        print(f"Error storing data in S3: {str(e)}")
        return False

def lambda_handler(event, context):
    """Main Lambda handler"""
    try:
        # Get environment variables
        bucket_name = os.environ['BUCKET_NAME']
        
        # Collect data
        inventory_data = {
            'timestamp': datetime.datetime.now().isoformat(),
            'account_id': context.invoked_function_arn.split(':')[4],
            'region': os.environ['AWS_REGION'],
            'ec2_instances': collect_ec2_data(),
            'security_groups': collect_security_groups(),
            'iam_configuration': collect_iam_info(),
            'vpc_configuration': collect_vpc_info()
        }
        
        # Store in S3
        if store_data_in_s3(inventory_data, bucket_name, 'ir_data'):
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'message': 'Data collection completed successfully',
                    'timestamp': inventory_data['timestamp']
                })
            }
        else:
            return {
                'statusCode': 500,
                'body': json.dumps({
                    'message': 'Failed to store collected data'
                })
            }
            
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': f'Error in data collection: {str(e)}'
            })
        }